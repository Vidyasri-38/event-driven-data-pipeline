import json
import boto3
import csv
import io
import os
from datetime import datetime

s3 = boto3.client("s3")

# Destination bucket for processed files and reports
DEST_BUCKET = os.environ.get("DEST_BUCKET")


# ==============================
# Process Individual CSV File
# ==============================
def process_s3_file(source_bucket, source_key):

    # Only process CSV files
    if not source_key.lower().endswith(".csv"):
        print(f"Skipping non-CSV file: {source_key}")
        return

    # Avoid recursive processing
    if source_key.startswith("processed/") or source_key.startswith("reports/"):
        print(f"Skipping internal file: {source_key}")
        return

    print(f"Processing CSV file: {source_key}")
    print(f"Source bucket: {source_bucket}")
    print(f"Destination bucket: {DEST_BUCKET}")

    # Read file from RAW bucket
    response = s3.get_object(Bucket=source_bucket, Key=source_key)
    content = response["Body"].read().decode("utf-8")

    csv_file = io.StringIO(content)
    reader = csv.DictReader(csv_file)

    total_records = 0
    total_amount = 0.0

    for row in reader:
        total_records += 1
        if row.get("amount"):
            try:
                total_amount += float(row["amount"])
            except ValueError:
                print(f"Invalid amount value in row: {row}")

    average_amount = total_amount / total_records if total_records > 0 else 0

    summary = {
        "source_file": source_key,
        "processed_at": datetime.utcnow().isoformat(),
        "total_records": total_records,
        "total_amount": total_amount,
        "average_amount": average_amount
    }

    output_key = f"processed/summary-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.json"

    # Save summary to PROCESSED bucket
    s3.put_object(
        Bucket=DEST_BUCKET,
        Key=output_key,
        Body=json.dumps(summary, indent=4).encode("utf-8"),
        ContentType="application/json"
    )

    print("CSV file processed successfully.")


# ==============================
# Generate Daily Aggregated Report
# ==============================
def generate_daily_report():

    print("Generating daily report...")

    response = s3.list_objects_v2(
        Bucket=DEST_BUCKET,
        Prefix="processed/"
    )

    total_files = 0
    grand_total_records = 0
    grand_total_amount = 0.0

    if "Contents" in response:
        for obj in response["Contents"]:

            # Skip folder objects
            if obj["Key"].endswith("/"):
                continue

            file_obj = s3.get_object(Bucket=DEST_BUCKET, Key=obj["Key"])
            content = json.loads(file_obj["Body"].read())

            grand_total_records += content.get("total_records", 0)
            grand_total_amount += content.get("total_amount", 0)
            total_files += 1

    daily_report = {
        "report_date": datetime.utcnow().strftime("%Y-%m-%d"),
        "files_processed": total_files,
        "total_records": grand_total_records,
        "total_amount": grand_total_amount
    }

    report_key = f"reports/daily-report-{datetime.utcnow().strftime('%Y%m%d')}.json"

    s3.put_object(
        Bucket=DEST_BUCKET,
        Key=report_key,
        Body=json.dumps(daily_report, indent=4).encode("utf-8"),
        ContentType="application/json"
    )

    print("Daily report generated successfully.")


# ==============================
# Main Lambda Handler
# ==============================
def lambda_handler(event, context):

    if not DEST_BUCKET:
        raise ValueError("DEST_BUCKET environment variable not set")

    print("Event received:", json.dumps(event))

    # Case 1: Triggered by S3 Upload
    if "Records" in event:
        source_bucket = event["Records"][0]["s3"]["bucket"]["name"]
        source_key = event["Records"][0]["s3"]["object"]["key"]
        process_s3_file(source_bucket, source_key)

    # Case 2: Triggered by EventBridge Schedule
    elif event.get("source") == "aws.events":
        generate_daily_report()

    else:
        print("Unknown event type")

    return {
        "statusCode": 200,
        "body": json.dumps("Execution completed successfully.")
    }
