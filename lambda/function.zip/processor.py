import json
import boto3
import csv
import io
import os
from datetime import datetime

s3 = boto3.client("s3")

DEST_BUCKET = os.environ.get("DEST_BUCKET")

def process_s3_file(source_bucket, source_key):
    print(f"Processing file: {source_key} from bucket: {source_bucket}")

    response = s3.get_object(Bucket=source_bucket, Key=source_key)
    content = response['Body'].read().decode('utf-8')

    csv_file = io.StringIO(content)
    reader = csv.DictReader(csv_file)

    total_records = 0
    total_amount = 0.0

    for row in reader:
        total_records += 1
        if 'amount' in row and row['amount']:
            total_amount += float(row['amount'])

    average_amount = total_amount / total_records if total_records > 0 else 0

    summary = {
        "source_file": source_key,
        "processed_at": datetime.utcnow().isoformat(),
        "total_records": total_records,
        "total_amount": total_amount,
        "average_amount": average_amount
    }

    summary_content = json.dumps(summary, indent=4)

    output_key = f"processed/summary-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.json"

    s3.put_object(
        Bucket=DEST_BUCKET,
        Key=output_key,
        Body=summary_content.encode("utf-8"),
        ContentType='application/json'
    )

    print("File processed successfully.")


def lambda_handler(event, context):
    try:
        if not DEST_BUCKET:
            raise ValueError("DEST_BUCKET environment variable not set")

        print("Received event:", json.dumps(event))

        # Case 1: S3 Upload Trigger
        if 'Records' in event:
            source_bucket = event['Records'][0]['s3']['bucket']['name']
            source_key = event['Records'][0]['s3']['object']['key']
            process_s3_file(source_bucket, source_key)

        # Case 2: Scheduled Event
        elif event.get("source") == "aws.events":
            print("Scheduled event triggered. No S3 file to process.")

            # Optional: You can add daily aggregation logic here
            # For now, just log success

        else:
            print("Unknown event type")

        return {
            "statusCode": 200,
            "body": json.dumps("Execution completed.")
        }

    except Exception as e:
        print(f"Error occurred: {str(e)}")
        raise e
